//
//  tabBarViewController.h
//  
//
//  Created by wanrun on 2016/12/16.
//
//

#import <UIKit/UIKit.h>

@interface tabBarViewController : UITabBarController

@end
