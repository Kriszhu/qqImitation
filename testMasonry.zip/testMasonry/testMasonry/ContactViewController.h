//
//  ContactViewController.h
//  testMasonry
//
//  Created by wanrun on 2016/12/16.
//  Copyright © 2016年 wanrun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactViewController : UIViewController

@end
