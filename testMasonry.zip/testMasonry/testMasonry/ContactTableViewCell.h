//
//  ContactTableViewCell.h
//  testMasonry
//
//  Created by wanrun on 2016/12/19.
//  Copyright © 2016年 wanrun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactTableViewCell : UITableViewCell
- (void)setData:(NSArray *)dic;
@end
